package com.olxchat

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class Worker(val id: Int, val web: WebView) {
    var pending: CompletableDeferred<String>? = null
    var loaded: CompletableDeferred<Unit>? = null
    @Volatile var picked = false
    var label: TextView? = null
}

class MainActivity : AppCompatActivity() {
    private val PRIMARY = Color.parseColor("#002f34")
    private val ACCENT = Color.parseColor("#00a89d")
    private val RED = Color.parseColor("#d31a1a")
    private val GREEN = Color.parseColor("#1b8a3a")
    private val ORANGE = Color.parseColor("#e08a00")
    private val PAGE_BG = Color.parseColor("#F4F6F7")
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private var defaultUa = ""

    private lateinit var drawer: DrawerLayout
    private lateinit var title: TextView
    private lateinit var chip: TextView
    private lateinit var etUrls: EditText
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var etMsg: EditText
    private lateinit var tvLinkCount: TextView
    private lateinit var tvPicInfo: TextView
    private lateinit var imgPreview: ImageView
    private lateinit var tvSent: TextView
    private lateinit var tvFail: TextView
    private lateinit var tvSkip: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvLog: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPause: Button
    private lateinit var winBox: LinearLayout
    private lateinit var loginWeb: WebView

    private val pages = LinkedHashMap<String, View>()
    private val titles = mapOf(
        "dash" to "Dashboard", "links" to "Links & Pages", "msg" to "Message & Picture",
        "set" to "Speed & Settings", "login" to "Login (OLX)"
    )
    private var current = "dash"
    private var loginLoaded = false

    private var speed = 1
    private var windows = 2
    private var desktop = true

    private var running = false
    private var paused = false
    private var picUri: Uri? = null
    private var imgData: String? = null
    private val workers = ArrayList<Worker>()
    private var wakeLock: PowerManager.WakeLock? = null
    private val fullLog = StringBuilder()
    private var sentCount = 0
    private var failCount = 0
    private var skipCount = 0
    private var doneTasks = 0

    private val prefs by lazy { getSharedPreferences("olx", MODE_PRIVATE) }

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            picUri = uri
            tvPicInfo.text = "Picture tayyar ho rahi hai..."
            imgPreview.setImageURI(uri)
            imgPreview.visibility = View.VISIBLE
            lifecycleScope.launch {
                val d = withContext(Dispatchers.IO) { prepareImage(uri) }
                imgData = d
                tvPicInfo.text = if (d != null) "Picture selected (har ad par text ke baad jayegi)" else "Picture load nahi hui"
            }
        }
    }

    inner class Bridge(private val w: Worker) {
        @JavascriptInterface
        fun result(s: String) { w.pending?.complete(s) }

        @JavascriptInterface
        fun wasPicked(): Boolean = w.picked
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(Color.WHITE, 12, Color.parseColor("#E0E4E6"))
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.setMargins(dp(12), dp(8), dp(12), 0)
        c.layoutParams = lp
        return c
    }

    private fun tv(t: String, size: Float = 13f, color: Int = PRIMARY, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun btn(t: String, color: Int): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 13f
        b.background = bg(color, 10)
        val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        b.layoutParams = lp
        return b
    }

    private fun edit(hintText: String, lines: Int = 1): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.minLines = lines
        e.textSize = 13f
        e.gravity = Gravity.TOP or Gravity.START
        e.background = bg(PAGE_BG, 8, Color.parseColor("#CFD6D9"))
        e.setPadding(dp(10), dp(8), dp(10), dp(8))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        e.layoutParams = lp
        return e
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        views.forEach { r.addView(it) }
        return r
    }

    private fun statCol(num: TextView, label: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        num.gravity = Gravity.CENTER
        c.addView(num)
        c.addView(tv(label, 11f, Color.GRAY))
        c.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        return c
    }

    private fun scrollPage(vararg views: View): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, 0, 0, dp(24))
        views.forEach { col.addView(it) }
        val s = ScrollView(this)
        s.isFillViewport = true
        s.setBackgroundColor(PAGE_BG)
        s.addView(col)
        return s
    }

    private fun menuItem(text: String, onClick: () -> Unit): TextView {
        val m = tv(text, 15f)
        m.setPadding(dp(20), dp(14), dp(20), dp(14))
        m.setOnClickListener { onClick() }
        return m
    }

    private fun setupWeb(web: WebView) {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.settings.userAgentString = if (desktop) desktopUa else defaultUa
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
    }

    // ---------- Activity ----------
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        speed = prefs.getInt("speed", 1)
        windows = prefs.getInt("win", 2)
        desktop = prefs.getBoolean("desktop", true)

        loginWeb = WebView(this)
        defaultUa = loginWeb.settings.userAgentString
        setupWeb(loginWeb)

        // ----- Top bar -----
        val menuBtn = tv("\u2630", 24f, Color.WHITE, true)
        menuBtn.setPadding(dp(16), dp(10), dp(16), dp(10))
        title = tv("Dashboard", 18f, Color.WHITE, true)
        chip = tv("IDLE", 11f, Color.WHITE, true)
        chip.setPadding(dp(10), dp(4), dp(10), dp(4))
        chip.background = bg(Color.GRAY, 14)
        val spacer = View(this)
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        topBar.setBackgroundColor(PRIMARY)
        topBar.setPadding(0, dp(6), dp(12), dp(6))
        topBar.addView(menuBtn)
        topBar.addView(title, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        topBar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        topBar.addView(chip)

        // ----- Dashboard -----
        tvSent = tv("0", 24f, GREEN, true)
        tvFail = tv("0", 24f, RED, true)
        tvSkip = tv("0", 24f, ORANGE, true)
        val statsCard = card()
        statsCard.addView(row(statCol(tvSent, "Sent"), statCol(tvFail, "Failed"), statCol(tvSkip, "Skipped (already sent)")))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 1
        progress.progress = 0
        tvInfo = tv("Taiyar. Menu se Links daalein, phir Start dabayein.", 12f, Color.DKGRAY)
        statsCard.addView(progress, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        statsCard.addView(tvInfo)

        val btnStart = btn("\u25B6  Start", GREEN)
        btnPause = btn("\u23F8  Pause", ORANGE)
        val btnStop = btn("\u23F9  Stop", RED)
        val btnRow = row(btnStart, btnPause, btnStop)
        val btnWrap = LinearLayout(this)
        btnWrap.setPadding(dp(9), dp(8), dp(9), 0)
        btnWrap.addView(btnRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val winHeader = tv("Live windows", 14f, PRIMARY, true)
        winHeader.setPadding(dp(14), dp(14), dp(14), 0)
        winBox = LinearLayout(this)
        winBox.orientation = LinearLayout.VERTICAL

        tvLog = tv("", 11f, Color.DKGRAY)
        val btnShare = btn("Log share karein", PRIMARY)
        btnShare.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(42))
        val logCard = card()
        logCard.addView(tv("Activity log", 14f, PRIMARY, true))
        logCard.addView(tvLog)
        logCard.addView(btnShare)

        val dashPage = scrollPage(statsCard, btnWrap, winHeader, winBox, logCard)

        // ----- Links page -----
        etUrls = edit("Har line mein 1 category link\nhttps://www.olx.com.pk/mobiles_c1411", 6)
        etStart = edit("Start page")
        etEnd = edit("End page")
        etStart.inputType = 2
        etEnd.inputType = 2
        etUrls.setText(prefs.getString("urls", ""))
        etStart.setText(prefs.getString("sp", "1"))
        etEnd.setText(prefs.getString("ep", "2"))
        tvLinkCount = tv("0 links", 12f, Color.GRAY)
        etUrls.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b2: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { tvLinkCount.text = countLinks().toString() + " links" }
        })
        tvLinkCount.text = countLinks().toString() + " links"
        val linksCard = card()
        linksCard.addView(tv("Category links (multi)", 14f, PRIMARY, true))
        linksCard.addView(etUrls)
        linksCard.addView(tvLinkCount)
        val pagesCard = card()
        pagesCard.addView(tv("Page range (har link ke liye)", 14f, PRIMARY, true))
        val s1 = tv("Start", 11f, Color.GRAY)
        val s2 = tv("End", 11f, Color.GRAY)
        val c1 = LinearLayout(this); c1.orientation = LinearLayout.VERTICAL; c1.addView(s1); c1.addView(etStart)
        val c2 = LinearLayout(this); c2.orientation = LinearLayout.VERTICAL; c2.addView(s2); c2.addView(etEnd)
        c1.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(0, 0, dp(6), 0) }
        c2.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        pagesCard.addView(row(c1, c2))
        val pageLinks = scrollPage(linksCard, pagesCard)

        // ----- Message page -----
        etMsg = edit("Aapka message", 4)
        etMsg.setText(prefs.getString("msg", "Salam, kya yeh available hai? Mujhse rabta karein."))
        val msgCard = card()
        msgCard.addView(tv("Message", 14f, PRIMARY, true))
        msgCard.addView(etMsg)
        val picCard = card()
        picCard.addView(tv("Picture (optional)", 14f, PRIMARY, true))
        val btnPic = btn("Pic chunein", ACCENT)
        val btnNoPic = btn("Pic hatao", Color.GRAY)
        picCard.addView(row(btnPic, btnNoPic))
        tvPicInfo = tv("Koi picture nahi", 12f, Color.DKGRAY)
        imgPreview = ImageView(this)
        imgPreview.visibility = View.GONE
        imgPreview.adjustViewBounds = true
        imgPreview.maxHeight = dp(160)
        picCard.addView(tvPicInfo)
        picCard.addView(imgPreview, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        val pageMsg = scrollPage(msgCard, picCard)

        // ----- Settings page -----
        val speedCard = card()
        speedCard.addView(tv("Speed", 14f, PRIMARY, true))
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        listOf("Slow (safe)", "Normal", "Fast").forEachIndexed { i, n ->
            val rb = RadioButton(this)
            rb.text = n
            rb.textSize = 13f
            rb.id = 1000 + i
            rg.addView(rb)
        }
        rg.check(1000 + speed)
        rg.setOnCheckedChangeListener { _, checkedId ->
            speed = checkedId - 1000
            prefs.edit().putInt("speed", speed).apply()
        }
        speedCard.addView(rg)
        speedCard.addView(tv("Fast mein slow internet par chat fail ho sakti hai, aur account block hone ka khatra badh jata hai.", 11f, Color.GRAY))

        val winCard = card()
        val tvWin = tv("Parallel windows: " + windows, 14f, PRIMARY, true)
        val sb = SeekBar(this)
        sb.max = 3
        sb.progress = windows - 1
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                windows = p + 1
                tvWin.text = "Parallel windows: " + windows
                prefs.edit().putInt("win", windows).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        winCard.addView(tvWin)
        winCard.addView(sb)
        winCard.addView(tv("Har link apni alag window mein saath chalega. 2-3 windows behtar hain, zyada se phone slow hoga.", 11f, Color.GRAY))

        val otherCard = card()
        val cbDesktop = CheckBox(this)
        cbDesktop.text = "Desktop site mode (recommended)"
        cbDesktop.isChecked = desktop
        cbDesktop.setOnCheckedChangeListener { _, on ->
            desktop = on
            prefs.edit().putBoolean("desktop", on).apply()
            loginWeb.settings.userAgentString = if (on) desktopUa else defaultUa
        }
        val btnBattery = btn("Battery allow (background ke liye)", PRIMARY)
        btnBattery.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(44))
        val btnClear = btn("Sent history clear", RED)
        btnClear.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(44))
        otherCard.addView(cbDesktop)
        otherCard.addView(btnBattery)
        otherCard.addView(btnClear)
        val pageSet = scrollPage(speedCard, winCard, otherCard)

        // ----- Login page -----
        val loginBox = LinearLayout(this)
        loginBox.orientation = LinearLayout.VERTICAL
        loginBox.setBackgroundColor(Color.WHITE)
        val loginHint = tv("Yahan OLX par ek baar login karein, phir Dashboard par jakar Start dabayein.", 12f, Color.DKGRAY)
        loginHint.setPadding(dp(14), dp(10), dp(14), dp(10))
        loginBox.addView(loginHint)
        loginBox.addView(loginWeb, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        pages["links"] = pageLinks
        pages["msg"] = pageMsg
        pages["set"] = pageSet
        pages["login"] = loginBox

        val frame = FrameLayout(this)
        frame.addView(dashPage, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        pages.values.forEach {
            it.visibility = View.GONE
            frame.addView(it, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        }

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.addView(topBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        content.addView(frame, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // ----- Drawer -----
        val menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        menu.setBackgroundColor(Color.WHITE)
        val brand = tv("OLX Chat Pro", 20f, Color.WHITE, true)
        brand.setBackgroundColor(PRIMARY)
        brand.setPadding(dp(20), dp(36), dp(20), dp(20))
        menu.addView(brand, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        menu.addView(menuItem("\uD83C\uDFE0   Dashboard") { show("dash") })
        menu.addView(menuItem("\uD83D\uDD17   Links & Pages") { show("links") })
        menu.addView(menuItem("\uD83D\uDCAC   Message & Picture") { show("msg") })
        menu.addView(menuItem("\u2699\uFE0F   Speed & Settings") { show("set") })
        menu.addView(menuItem("\uD83D\uDD11   Login (OLX)") { show("login") })
        val div = View(this)
        div.setBackgroundColor(Color.parseColor("#E0E4E6"))
        menu.addView(div, LinearLayout.LayoutParams(MATCH_PARENT, dp(1)))
        menu.addView(menuItem("\u25B6   Start") { show("dash"); doStart() })
        menu.addView(menuItem("\u23EF   Pause / Resume") { doPause() })
        menu.addView(menuItem("\u23F9   Stop") { doStop() })

        drawer = DrawerLayout(this)
        drawer.addView(content, DrawerLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        val dlp = DrawerLayout.LayoutParams(dp(280), MATCH_PARENT)
        dlp.gravity = Gravity.START
        drawer.addView(menu, dlp)
        setContentView(drawer)

        menuBtn.setOnClickListener { drawer.openDrawer(Gravity.START) }
        btnStart.setOnClickListener { doStart() }
        btnPause.setOnClickListener { doPause() }
        btnStop.setOnClickListener { doStop() }
        btnPic.setOnClickListener { pickImage.launch("image/*") }
        btnNoPic.setOnClickListener {
            picUri = null; imgData = null
            imgPreview.visibility = View.GONE
            tvPicInfo.text = "Koi picture nahi"
        }
        btnClear.setOnClickListener { prefs.edit().remove("sent").apply(); log("Sent history clear ho gayi.") }
        btnBattery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        btnShare.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, fullLog.toString())
            startActivity(Intent.createChooser(i, "Log share karein"))
        }
    }

    override fun onPause() {
        super.onPause()
        savePrefs()
        CookieManager.getInstance().flush()
        if (running) workers.firstOrNull()?.web?.resumeTimers()
    }

    override fun onStop() {
        super.onStop()
        if (running) workers.firstOrNull()?.web?.resumeTimers()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (drawer.isDrawerOpen(Gravity.START)) drawer.closeDrawers()
        else if (current != "dash") show("dash")
        else moveTaskToBack(true)
    }

    // ---------- Navigation / state ----------
    private fun show(key: String) {
        if (current == "login" && key != "login") CookieManager.getInstance().flush()
        current = key
        pages.values.forEach { it.visibility = View.GONE }
        pages[key]?.visibility = View.VISIBLE
        title.text = titles[key] ?: "Dashboard"
        if (key == "login" && !loginLoaded) {
            loginLoaded = true
            loginWeb.loadUrl("https://www.olx.com.pk")
        }
        drawer.closeDrawers()
    }

    private fun setState(t: String, color: Int) {
        runOnUiThread {
            chip.text = t
            chip.background = bg(color, 14)
        }
    }

    private fun log(s: String) {
        fullLog.append(s).append("\n")
        runOnUiThread { tvLog.text = (s + "\n" + tvLog.text.toString()).take(4000) }
    }

    private fun refreshStats() {
        tvSent.text = sentCount.toString()
        tvFail.text = failCount.toString()
        tvSkip.text = skipCount.toString()
    }

    private fun countLinks(): Int = etUrls.text.toString().lines().count { it.contains("olx.com.pk") }

    private fun savePrefs() {
        prefs.edit()
            .putString("urls", etUrls.text.toString())
            .putString("sp", etStart.text.toString())
            .putString("ep", etEnd.text.toString())
            .putString("msg", etMsg.text.toString())
            .apply()
    }

    private fun doPause() {
        if (!running) return
        paused = !paused
        btnPause.text = if (paused) "\u25B6  Resume" else "\u23F8  Pause"
        if (paused) setState("PAUSING", ORANGE) else setState("RUNNING", GREEN)
    }

    private fun doStop() {
        if (!running) return
        running = false
        paused = false
        workers.forEach {
            it.pending?.complete("")
            it.loaded?.complete(Unit)
        }
        setState("STOPPING", RED)
    }

    private fun prepareImage(uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val maxSide = 1280
            val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
            } else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            null
        }
    }

    private fun acquireWake() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "olxchat:run")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) { }
    }

    private fun releaseWake() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) { }
    }

    // ---------- Workers ----------
    private fun speedK(): Double = when (speed) { 0 -> 1.5; 2 -> 0.6; else -> 1.0 }

    private suspend fun betweenAds() {
        val mn: Long; val mx: Long
        when (speed) {
            0 -> { mn = 5000; mx = 9000 }
            2 -> { mn = 1500; mx = 3000 }
            else -> { mn = 3000; mx = 6000 }
        }
        delay(mn + (Math.random() * (mx - mn)).toLong())
    }

    private fun createWorker(i: Int): Worker {
        val web = WebView(this)
        setupWeb(web)
        val w = Worker(i, web)
        web.addJavascriptInterface(Bridge(w), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { w.loaded?.complete(Unit) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                wv: WebView?,
                cb: ValueCallback<Array<Uri>>?,
                p: WebChromeClient.FileChooserParams?
            ): Boolean {
                val u = picUri
                if (u != null) {
                    w.picked = true
                    cb?.onReceiveValue(arrayOf(u))
                } else {
                    cb?.onReceiveValue(null)
                }
                return true
            }
        }
        val c = card()
        val lbl = tv("Window " + (i + 1) + ": idle", 12f, PRIMARY, true)
        w.label = lbl
        c.addView(lbl)
        c.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, dp(220)))
        winBox.addView(c)
        return w
    }

    private fun setWin(w: Worker, t: String) {
        w.label?.text = "Window " + (w.id + 1) + ": " + t
    }

    private suspend fun navigate(w: Worker, url: String) {
        w.loaded = CompletableDeferred()
        w.web.loadUrl(url)
        withTimeoutOrNull(25000) { w.loaded!!.await() }
        delay((3500 * speedK()).toLong())
    }

    private suspend fun runJs(w: Worker, script: String, timeout: Long): String {
        w.pending = CompletableDeferred()
        w.web.evaluateJavascript(script, null)
        return withTimeoutOrNull(timeout) { w.pending!!.await() } ?: ""
    }

    private suspend fun checkpoint(): Boolean {
        while (paused && running) delay(500)
        return running
    }

    private fun parseUrls(raw: String): List<String> {
        return try {
            val a = JSONArray(raw)
            val out = ArrayList<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (ex: Exception) {
            emptyList()
        }
    }

    private suspend fun processCategory(
        w: Worker, cat: String, sp: Int, ep: Int, msg: String,
        sent: MutableSet<String>, claimed: MutableSet<String>, catIdx: Int, catTotal: Int
    ) {
        val base = cat.substringBefore("?")
        val name = base.trimEnd('/').substringAfterLast('/')
        for (page in sp..ep) {
            if (!checkpoint()) return
            setWin(w, name + " | page " + page + " scan")
            navigate(w, base + "?page=" + page)
            var urls = parseUrls(runJs(w, LINKS_JS.replace("__SPD__", speedK().toString()), 25000))
            if (urls.isEmpty()) {
                delay(4000)
                urls = parseUrls(runJs(w, LINKS_JS.replace("__SPD__", speedK().toString()), 25000))
            }
            val fresh = ArrayList<String>()
            for (u in urls) {
                if (u in sent) { skipCount++; continue }
                if (claimed.add(u)) fresh.add(u)
            }
            refreshStats()
            var n = 0
            for (u in fresh) {
                if (!checkpoint()) return
                n++
                setWin(w, name + " | p" + page + " | ad " + n + "/" + fresh.size)
                navigate(w, u)
                w.picked = false
                val img = imgData
                val script = CHAT_JS
                    .replace("__SPD__", speedK().toString())
                    .replace("__MSG__", JSONObject.quote(msg))
                    .replace("__IMG__", if (img != null) JSONObject.quote(img) else "null")
                val raw = runJs(w, script, 90000)
                val status = try { JSONObject(raw).getString("status") } catch (e: Exception) { "No response" }
                val ttl = try { JSONObject(raw).getString("title").take(28) } catch (e: Exception) { u }
                log("W" + (w.id + 1) + " [" + name + " p" + page + "] " + ttl + " -> " + status)
                if (status.contains("Sent")) {
                    sentCount++
                    sent.add(u)
                    prefs.edit().putStringSet("sent", sent).apply()
                } else {
                    failCount++
                }
                refreshStats()
                betweenAds()
            }
            doneTasks++
            progress.progress = doneTasks
            tvInfo.text = "Link " + catIdx + "/" + catTotal + " | pages done: " + doneTasks + "/" + progress.max
        }
    }

    private fun doStart() {
        if (running) { log("Pehle se chal raha hai."); return }
        val cats = etUrls.text.toString().lines().map { it.trim() }.filter { it.contains("olx.com.pk") }
        val sp = etStart.text.toString().toIntOrNull() ?: 1
        val ep = etEnd.text.toString().toIntOrNull() ?: 1
        val msg = etMsg.text.toString().trim()
        if (cats.isEmpty()) { Toast.makeText(this, "Pehle Links page par category link daalein", Toast.LENGTH_LONG).show(); return }
        if (msg.isEmpty()) { Toast.makeText(this, "Message likhein", Toast.LENGTH_LONG).show(); return }
        if (sp < 1 || sp > ep) { Toast.makeText(this, "Valid page range daalein", Toast.LENGTH_LONG).show(); return }
        savePrefs()

        running = true
        paused = false
        sentCount = 0; failCount = 0; skipCount = 0; doneTasks = 0
        refreshStats()
        progress.max = cats.size * (ep - sp + 1)
        progress.progress = 0
        btnPause.text = "\u23F8  Pause"
        setState("RUNNING", GREEN)
        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        acquireWake()

        lifecycleScope.launch {
            try {
                val sent = prefs.getStringSet("sent", emptySet())!!.toMutableSet()
                val claimed = HashSet<String>()
                winBox.removeAllViews()
                workers.clear()
                val count = minOf(windows, cats.size)
                for (i in 0 until count) workers.add(createWorker(i))

                val chan = Channel<Pair<Int, String>>(Channel.UNLIMITED)
                cats.forEachIndexed { idx, c -> chan.trySend(Pair(idx + 1, c)) }
                chan.close()

                val jobs = workers.map { w ->
                    launch {
                        try {
                            for (item in chan) {
                                if (!running) break
                                processCategory(w, item.second, sp, ep, msg, sent, claimed, item.first, cats.size)
                            }
                            setWin(w, "complete")
                        } catch (e: Exception) {
                            log("Window " + (w.id + 1) + " error: " + e.message)
                        }
                    }
                }
                jobs.forEach { it.join() }
                log("Finished / stopped. Sent: " + sentCount + ", Failed: " + failCount)
            } finally {
                running = false
                paused = false
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
                releaseWake()
                setState("IDLE", Color.GRAY)
                btnPause.text = "\u23F8  Pause"
                tvInfo.text = "Khatam. Sent: " + sentCount + " | Failed: " + failCount
                workers.forEach {
                    (it.web.parent as? ViewGroup)?.removeView(it.web)
                    it.web.destroy()
                }
                workers.clear()
            }
        }
    }

    companion object {
        const val LINKS_JS = """
(async function(){
  const K=__SPD__;
  const wait=ms=>new Promise(r=>setTimeout(r,Math.round(ms*K)));
  for(let i=0;i<4;i++){window.scrollBy(0,1500);await wait(700);}
  const urls=[];
  document.querySelectorAll('a[href*="/item/"]').forEach(a=>{
    const h=a.getAttribute('href'); if(!h) return;
    let f=h.startsWith('http')?h:'https://www.olx.com.pk'+h;
    f=f.split('?')[0]; if(!urls.includes(f)) urls.push(f);
  });
  Android.result(JSON.stringify(urls));
})();
"""
        const val CHAT_JS = """
(async function(){
  const K=__SPD__;
  const wait=ms=>new Promise(r=>setTimeout(r,Math.round(ms*K)));
  let title='Unknown Title', price='N/A', status='Chat Failed';
  const IMG=__IMG__;
  const ATT='M537.07 92.46';
  function done(){Android.result(JSON.stringify({title:title,price:String(price),status:status}));}
  function findSend(){
    const c=Array.from(document.querySelectorAll('button,[role="button"],[data-aut-id*="send"]'));
    for(const el of c){
      if(el.innerHTML&&el.innerHTML.includes(ATT)) continue;
      const t=((el.innerText||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
      if(t.includes('send')) return el;
    }
    return null;
  }
  try{
    const s=document.querySelector('script[type="application/ld+json"]');
    if(s){const j=JSON.parse(s.innerText); if(j.name) title=j.name;
      if(j.offers) price=Array.isArray(j.offers)?(j.offers[0].price||'N/A'):(j.offers.price||'N/A');}
  }catch(e){}
  if(title==='Unknown Title'){const h=document.querySelector('h1'); if(h) title=h.innerText;}
  try{
    const all=Array.from(document.querySelectorAll('button, a, span'));
    const chatBtn=all.find(b=>{
      const t=(b.innerText||'').toLowerCase().trim();
      const a=(b.getAttribute('aria-label')||'').toLowerCase().trim();
      return t.includes('chat')||a.includes('chat');
    });
    if(!chatBtn){status='Chat Hidden';done();return;}
    chatBtn.click(); await wait(4000);
    const input=document.querySelector('textarea')||
      document.querySelector('input[placeholder*="message" i]')||
      document.querySelector('input[placeholder*="Write" i]')||
      document.querySelector('div[contenteditable="true"]')||
      document.querySelector('div[role="textbox"]');
    if(!input){status='Field Blocked / Not Logged In';done();return;}
    input.focus(); input.click(); await wait(500);
    const msg=__MSG__;
    if(input.isContentEditable){input.textContent=msg; input.dispatchEvent(new Event('input',{bubbles:true}));}
    else{
      const proto=input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto,'value').set.call(input,msg);
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
    }
    await wait(1200);
    const sendBtn=findSend();
    if(sendBtn){sendBtn.click(); status='Message Sent';}
    else{
      const o={key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true};
      input.dispatchEvent(new KeyboardEvent('keydown',o));
      input.dispatchEvent(new KeyboardEvent('keypress',o));
      input.dispatchEvent(new KeyboardEvent('keyup',o));
      status='Sent (Enter)';
    }
    await wait(2000);

    if(IMG){
      let handled=false;
      const origClick=HTMLInputElement.prototype.click;
      const origPicker=HTMLInputElement.prototype.showPicker;
      let cap=null;
      try{
        const mime=IMG.substring(5,IMG.indexOf(';'));
        const bin=atob(IMG.split(',')[1]);
        const bytes=new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++) bytes[i]=bin.charCodeAt(i);
        const file=new File([bytes],'photo.jpg',{type:mime||'image/jpeg'});
        const applyTo=(inp)=>{
          const dt=new DataTransfer(); dt.items.add(file); inp.files=dt.files;
          inp.dispatchEvent(new Event('input',{bubbles:true}));
          inp.dispatchEvent(new Event('change',{bubbles:true}));
          handled=true;
        };
        HTMLInputElement.prototype.click=function(){
          if(this.type==='file'){applyTo(this);return;}
          return origClick.apply(this,arguments);
        };
        if(origPicker){
          HTMLInputElement.prototype.showPicker=function(){
            if(this.type==='file'){applyTo(this);return;}
            return origPicker.apply(this,arguments);
          };
        }
        cap=(e)=>{
          const t=e.target; let inp=t.closest&&t.closest('input[type="file"]');
          if(!inp&&t.closest){const lb=t.closest('label'); if(lb&&lb.control&&lb.control.type==='file') inp=lb.control;}
          if(inp){e.preventDefault(); applyTo(inp);}
        };
        document.addEventListener('click',cap,true);

        const findPath=(r)=>Array.from(r.querySelectorAll('path')).find(p=>(p.getAttribute('d')||'').startsWith(ATT))||null;
        let icon=null; let scope=input;
        for(let i=0;i<8&&scope&&!icon;i++){scope=scope.parentElement; if(scope) icon=findPath(scope);}
        if(!icon) icon=findPath(document);
        let target=null;
        if(icon) target=icon.closest('button,[role="button"],label,a')||icon.closest('svg').parentElement;
        if(!target){
          target=Array.from(document.querySelectorAll('button,[role="button"],label,[data-aut-id]')).find(el=>{
            const t=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.getAttribute('data-aut-id')||'')).toLowerCase();
            return /attach|upload|photo|image|clip/.test(t);
          })||null;
        }
        if(target){target.click(); await wait(2500);}
        if(!handled){const fi=document.querySelector('input[type="file"]'); if(fi) applyTo(fi); await wait(1500);}
        if(!handled && Android.wasPicked()) handled=true;
        if(handled){
          await wait(2500);
          const b2=findSend();
          if(b2) b2.click();
          await wait(2000);
          status+=' + Pic';
        } else { status+=' (Pic attach nahi hui)'; }
      }catch(e){ status+=' (Pic error)'; }
      finally{
        HTMLInputElement.prototype.click=origClick;
        if(origPicker) HTMLInputElement.prototype.showPicker=origPicker;
        if(cap) document.removeEventListener('click',cap,true);
      }
    }
  }catch(e){status='Error';}
  done();
})();
"""
    }
}
